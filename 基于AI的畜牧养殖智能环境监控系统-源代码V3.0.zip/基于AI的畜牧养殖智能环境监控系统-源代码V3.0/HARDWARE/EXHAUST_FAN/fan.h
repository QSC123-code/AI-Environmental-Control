#ifndef __FAN_H
#define __FAN_H
#include "sys.h"

#define EVENT_Current5 (0x01<<13)           //排风扇电流事件标志

#define FAN_GEAR1       80                  //1档速度
#define FAN_GEAR2       90                  //2档速度
#define FAN_GEAR3       100                 //3档速度
/* 排风扇引脚 */
#define FAN_GPIO_Pin1		GPIO_Pin_14 
#define FAN_GPIO_Pin2		GPIO_Pin_15
#define FAN_GPIO_Pin3		GPIO_Pin_0
#define FAN_GPIO_Pin4		GPIO_Pin_1
#define FAN_GPIO_Pin5		GPIO_Pin_5
#define FAN_GPIO_Pin6		GPIO_Pin_6
#define FAN_GPIO_Pin7		GPIO_Pin_15
#define FAN_GPIO_Pin8		GPIO_Pin_3
/* 排风扇引脚端口 */
#define FAN_GPIO_PORT1	GPIOB
#define FAN_GPIO_PORT2	GPIOA
#define FAN_GPIO_PORT3	GPIOE
/* 排风扇定时器 */
#define FAN_TIM1				TIM12
#define FAN_TIM2				TIM5
#define FAN_TIM3				TIM9
#define FAN_TIM4				TIM2
/* 排风扇定时器引脚复用 */
#define FAN_AF_TIM1     GPIO_AF_TIM12
#define FAN_AF_TIM2     GPIO_AF_TIM5
#define FAN_AF_TIM3     GPIO_AF_TIM9
#define FAN_AF_TIM4     GPIO_AF_TIM2
/* 排风扇引脚源 */
#define FAN_PIO_PinSource1 GPIO_PinSource14
#define FAN_PIO_PinSource2 GPIO_PinSource15
#define FAN_PIO_PinSource3 GPIO_PinSource0
#define FAN_PIO_PinSource4 GPIO_PinSource1
#define FAN_PIO_PinSource5 GPIO_PinSource5
#define FAN_PIO_PinSource6 GPIO_PinSource6
#define FAN_PIO_PinSource7 GPIO_PinSource15
#define FAN_PIO_PinSource8 GPIO_PinSource3
/* 排风扇时钟 */
#define FAN_APB1Periph1 	 RCC_APB1Periph_TIM12
#define FAN_APB1Periph2 	 RCC_APB1Periph_TIM5
#define FAN_APB2Periph3 	 RCC_APB2Periph_TIM9
#define FAN_APB1Periph4 	 RCC_APB1Periph_TIM2
/* 排风扇GPIO时钟 */
#define FAN_AHB1Periph_GPIO1  RCC_AHB1Periph_GPIOA
#define FAN_AHB1Periph_GPIO2  RCC_AHB1Periph_GPIOB
#define FAN_AHB1Periph_GPIO3  RCC_AHB1Periph_GPIOE

void fan_init(void);                            //排风扇初始化
void fan_start(u8 gear);                        //排风扇启动
void fan_stop(void);                            //排风扇停止

#endif





