#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 

#define USART_REC_LEN  			200  	 //�������ֽ���
#define EN_USART1_RX 			1		

#define uchar    unsigned char
#define uint8    unsigned char
#define uint16   unsigned short int
#define uint32   unsigned long
#define int16    short int
#define int32    long
	  	
extern u8  USART_RX_BUF[USART_REC_LEN]; //���ջ�����
extern u16 USART_RX_STA;         		
//���庯������
void uart_init(u32 bound);
void uart2_init(u32 bound);
void uart3_init(u32 bound);
void Uart3_SendStr(char* SendBuf);
void Uart3_SendChar(uint8_t ch);
void Uart1_SendChar(uint8_t ch);
void  SendChar(uchar t);
void uart2_init(u32 bound);
#endif


