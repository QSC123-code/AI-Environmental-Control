#ifndef __4G_H
#define __4G_H

#include "sys.h"

//��Ϊ��ƽ̨��Ϣ
#define HUAWEI_MQTT_USERNAME			"68b40181d582f200184aa333_OTA_Test"                                 //�豸����
#define HUAWEI_MQTT_PASSWORD			"5a57f0a27a8a0f3ea5f6437d35fb11aff4ab7c05de8b07274a321bab16be5e1e"  //�豸��Կ
#define HUAWEI_MQTT_ClientID			"68b40181d582f200184aa333_OTA_Test_0_0_2025083108"                  //�ͻ���ID
#define HUAWEI_MQTT_ADDRESS				"83636d7850.st1.iotda-device.cn-north-4.myhuaweicloud.com"          //��Ϊ�Ƶ�ַ
#define HUAWEI_MQTT_PORT				"1883"                                                              //MQTT�˿�
#define HUAWEI_MQTT_DeviceID			"68b40181d582f200184aa333_OTA_Test"                                 //�豸ID
#define HUAWEI_MQTT_ServiceID			"OTA"                                                               //����ID

void My4G_Init(void);
void U3_Event(uint8_t *data,uint16_t datalen);

#endif


