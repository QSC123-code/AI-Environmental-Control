#ifndef __KEY_H
#define __KEY_H
#include "stm32f10x.h"

void key_init(void);
u8 key_Scan(u8 mode);

#endif

