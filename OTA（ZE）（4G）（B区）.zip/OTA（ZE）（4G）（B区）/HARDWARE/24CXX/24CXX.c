#include "24CXX.h"
#include "iic.h"
#include "delay.h"
#include "main.h"
#include "string.h"

/**
 * @brief 从AT24CXX存储器中读取一个字节的数据,先判断型号，然后发送写命令，将高8位地址写入，仔将低8位地址写入，最后读数据返回
 * @param ReadAddr 要读取的地址
 * @return 读取到的8位数据
 */
u8 AT24CXX_ReadOneByte(u16 ReadAddr)
{
	u8 temp;  						// 用于存储读取到的临时数据
	IIC_Start();					//开始
	if(EE_TYPE>AT24C16)				//大容量
	{
		IIC_Send_Byte(0xA0);		//写命令
		IIC_Wait_Ack();				//等待应答
		IIC_Send_Byte(ReadAddr>>8); //先发送高八位
		IIC_Wait_Ack();				//等待应答
	}else IIC_Send_Byte(0xA0+((ReadAddr/256)<<1));
	IIC_Wait_Ack();
	IIC_Send_Byte(ReadAddr%256);	//发送低八位
	IIC_Wait_Ack();
	IIC_Start();					//开始
	IIC_Send_Byte(0xA1);			//开启接收模式
	IIC_Wait_Ack();
	temp=IIC_Read_Byte(0);			//接收数据，0代表非应答
	IIC_Stop();
	return temp;
}
	
/**
 * @brief 从AT24CXX存储器中指定地址中写入一个字节的数据
 * @param WriteAddr 要写入的地址
 * @param DataToWrite 要写入的数据
 */
void AT24CXX_WriteOneByte(u16 WriteAddr,u8 DataToWrite)
{
	IIC_Start();						//开始
	if(EE_TYPE>AT24C16)					//大容量
	{
		IIC_Send_Byte(0xA0);			//写命令
		IIC_Wait_Ack();					//等待应答
		IIC_Send_Byte(WriteAddr/256);	//先发送高八位
	}else IIC_Send_Byte(0xA0+((WriteAddr/256)<<1));
	IIC_Wait_Ack();
	IIC_Send_Byte(WriteAddr%256);		//发送低八位
	IIC_Wait_Ack();
	IIC_Send_Byte(DataToWrite);			//发送一个字节
	IIC_Wait_Ack();
	IIC_Stop();
	delay_ms(10);
}
	
/**
 * @brief 从AT24CXX存储器中指定地址中写入一定字节的数据
 * @param WriteAddr 要写入的地址
 * @param DataToWrite 要写入的数据
 * @param Len 要写入的字节数
 */
void AT24CXX_WriteLenByte(u16 WriteAddr,u32 DataToWrite,u8 Len)
{
	for(int i=0;i<Len;i++)
	{
		AT24CXX_WriteOneByte(WriteAddr+i,(DataToWrite>>(8*i))&0xff);
	}
}
	
/**
 * @brief 从AT24CXX存储器中指定地址中读出一定字节的数据
 * @param ReadAddr 要读取的地址
 * @param Len 要读取的字节数
 */
u32 AT24CXX_ReadLenByte(u16 ReadAddr,u8 Len)
{
	u32 temp;
	for(int i=0;i<Len;i++)
	{
		temp<<=8;
		temp+=AT24CXX_ReadOneByte(ReadAddr+Len-i-1);	//先读出最高地址的数据放到最高位
	}
	return temp;
}

/**
 * @brief 从AT24CXX存储器中指定地址中写入一定长度数据
 * @param WriteAddr :开始写入的地址
 * @param pBuffer   :数据数组首地址
 * @param NumToWrite:要写入的字节数
 */
void AT24CXX_Write(u16 WriteAddr,u8 *pBuffer,u16 NumToWrite)
{
	while(NumToWrite--)
	{
		AT24CXX_WriteOneByte(WriteAddr,*pBuffer);
		WriteAddr++;			//地址下一位
		pBuffer++;				//数据下一位
	}
}
	
/**
 * @brief 从AT24CXX存储器中指定地址中读出一定长度数据
 * @param ReadAddr 	:开始读取的地址
 * @param pBuffer   :数据数组首地址
 * @param NumToRead :要读取的字节数
 */
void AT24CXX_Read(u16 ReadAddr,u8 *pBuffer,u16 NumToRead)
{
	while(NumToRead--)
	{
		*pBuffer=AT24CXX_ReadOneByte(ReadAddr);
		pBuffer++;
		ReadAddr++;
	}
}	

/**
 * @brief 检查存储器类型
 * @param 无
 */
u8 AT24CXX_Check(void)
{
	u8 temp;
	temp=AT24CXX_ReadOneByte(255);		   
	if(temp==0X55)return 0;		   
	else
	{
		AT24CXX_WriteOneByte(255,0X55);
	    temp=AT24CXX_ReadOneByte(255);	  
		if(temp==0X55)return 0;
	}
	return 1;	
}  

/**
 * @brief 初始化IIC
 * @param 无
 */
void AT24CXX_Init(void)
{
	IIC_Init();
}

/**
 * @brief 从AT24CXX存储器中读取OTA信息
 * @param 无
 */
void AT24CXX_ReadOTAInfo(void)
{
	memset(&OTA_Info,0,OTA_INFOCB_SIZE);
	AT24CXX_Read(0,(uint8_t*)&OTA_Info,OTA_INFOCB_SIZE);
}

/**
 * @brief 从AT24CXX存储器中写入OTA信息
 * @param 无
 */
void AT24CXX_WriteOTAInfo(void)
{
	uint8_t i;
	uint8_t *wptr;
	wptr=(uint8_t *)&OTA_Info;				//写入数据
	for(i=0;i<STM32_PAGE_SIZE/16;i++)		//每页16个字节
	{
		AT24CXX_Write(i*16,wptr+i*16,16);	//每页写16个字节
		delay_ms(5);
	}
}




