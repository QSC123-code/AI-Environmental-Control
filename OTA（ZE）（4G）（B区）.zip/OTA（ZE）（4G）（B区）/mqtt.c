uint8_t http_download(const char *url, const char *token, uint32_t file_size)
{
    uint32_t offset = 0;
    uint16_t chunk;
    uint8_t  *data_ptr;
    char     range_hdr[64];
    static uint32_t flash_addr = 0;   /* W25Q64 ?????? */

    /* 1. HTTP ????????????? */
    u3_printf("AT+QHTTPCFG=\"contextid\",1\r\n");
    delay_ms(300);
    if (strstr(url, "https://"))
    {
        u3_printf("AT+QHTTPCFG=\"sslctxid\",1\r\n");
        delay_ms(300);
    }
    u3_printf("AT+QHTTPCFG=\"reqheader/add\",\"Authorization\",\"Bearer %s\"\r\n", token);
    delay_ms(300);

    /* 2. ?????? */
    while (offset < file_size)
    {
        chunk = (file_size - offset) > CHUNK_SZ ? CHUNK_SZ : (file_size - offset);

        /* 2.1 Range */
        sprintf(range_hdr, "bytes=%lu-%lu", offset, offset + chunk - 1);
        u3_printf("AT+QHTTPCFG=\"reqheader/add\",\"Range\",\"%s\"\r\n", range_hdr);
        delay_ms(200);

        /* 2.2 URL */
        u3_printf("AT+QHTTPURL=%d,60\r\n", (int)strlen(url));
        delay_ms(500);
        u3_printf("%s\r\n", url);
        delay_ms(500);

        /* 2.3 GET */
        u3_printf("AT+QHTTPGET=120\r\n");
        delay_ms(500);

        /* 2.4 ??? 206 ?????????????????��? */
        uint32_t t0 = GetTickCount();
        while (strstr((char *)U3_RxBuff, "+QHTTPGET: 0,206,") == NULL)
        {
            if (GetTickCount() - t0 > 10000) break;
            delay_ms(50);
        }

        /* 2.5 ??????? */
        u3_printf("AT+QHTTPREAD=120\r\n");
        delay_ms(500);

        /* 2.6 ??? CONNECT????????��????????? CONNECT???????????? */
        t0 = GetTickCount();
        while (strstr((char *)U3_RxBuff, "CONNECT") == NULL)
        {
            if (GetTickCount() - t0 > 5000) break;
            delay_ms(50);
        }

        /* 2.7 ??��?????? */
        char *connect_line = strstr((char *)U3_RxBuff, "CONNECT");
        char *data_start   = connect_line ? strchr(connect_line, '\n') : NULL;
        if (data_start) data_start++;          /* ???? '\n' */
        else            data_start = (char *)U3_RxBuff;

        char *body_start = strstr(data_start, "\r\n\r\n");
        if (body_start) body_start += 4;
        else            body_start = data_start;

        uint32_t header_len = body_start - (char *)U3_RxBuff;
        uint32_t body_len   = chunk - header_len;
        if (body_len > sizeof(firmware_buffer)) body_len = sizeof(firmware_buffer);

        memcpy(firmware_buffer, body_start, body_len);

        /* 2.8 ��?? W25Q64 */
        for (uint16_t i = 0; i < body_len; i += PAGE_SZ)
        {
            uint16_t write_len = (body_len - i) > PAGE_SZ ? PAGE_SZ : (body_len - i);
            W25QXX_Write_Page(&firmware_buffer[i], flash_addr, write_len);
            flash_addr += write_len;
        }

        offset += body_len;
        u1_printf("?????? %lu / %lu ???????��?? %lu??\r\n", offset, file_size, body_len);
    }

    /* 3. ?????????? */
    firmware_length = file_size;
    u1_printf("OTA ????????????? %lu ???\r\n", firmware_length);

    u3_printf("AT+QHTTPSTOP\r\n");
    delay_ms(200);
    return 1;
}