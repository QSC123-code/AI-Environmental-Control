#ifndef __MQTT_H
#define __MQTT_H
#include "sys.h"

#define HUAWEI_MQTT_USERNAME			"68b40181d582f200184aa333_OTA_Test"                                 //��Ϊ���û���
#define HUAWEI_MQTT_PASSWORD			"5a57f0a27a8a0f3ea5f6437d35fb11aff4ab7c05de8b07274a321bab16be5e1e"  //��Ϊ����Կ
#define HUAWEI_MQTT_ClientID			"68b40181d582f200184aa333_OTA_Test_0_0_2025083108"                  //ClientID
#define HUAWEI_MQTT_ADDRESS				"83636d7850.st1.iotda-device.cn-north-4.myhuaweicloud.com"          //��Ϊ�Ƶ�ַ
#define HUAWEI_MQTT_PORT				"1883"                                                              //MQTT�˿�
#define HUAWEI_MQTT_DeviceID			"68b40181d582f200184aa333_OTA_Test"                                 //�豸ID
#define HUAWEI_MQTT_ServiceID			"OTA"                                                               //����ID

/* ��Ϊ��ƽ̨��Ԫ�� */
#define CLIENTID						"68b40181d582f200184aa333_OTA_Test_0_0_2025090106"
#define USERNAME						"68b40181d582f200184aa333_OTA_Test"
#define PASSWORD						"5a57f0a27a8a0f3ea5f6437d35fb11aff4ab7c05de8b07274a321bab16be5e1e"

void MQTT_connectpack(void);                                                        //���ӻ�Ϊ��
void MQTT_Subcribpack(char *topic);                                                 //��������
void OTA_Version(void);                                                             //��ȡ�汾��
uint8_t OTA_VersionSavedata(uint8_t *t_payload);                                    //����汾��
void OTA_Upgrade(void);                                                             //����
uint8_t MQTT_UpgradeSavedata(uint8_t *t_payload);                                   //����������Ϣ
void OTA_Download(uint8_t *data,uint16_t datalen);                                  //���ع̼�
uint8_t http_download(const char *url, const char *token, uint32_t file_size);      //���ع̼�
void Timer_Init(void);                                                              //��ʱ����ʼ��                              
uint32_t GetTickCount(void);                                                        //��ȡϵͳʱ��

#endif




