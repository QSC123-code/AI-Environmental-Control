#ifndef _FLASH_H
#define _FLASH_H

#include "sys.h"

void STM32_EraseFlash(uint16_t start,uint16_t num);                     //����flash
void STM32_WriteFlash(uint32_t addr, uint32_t *wdata, uint32_t num);    //д��flash

#endif


